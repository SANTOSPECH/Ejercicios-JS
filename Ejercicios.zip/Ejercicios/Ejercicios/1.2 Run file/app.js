// app.js

const math = require('./math'); // Importamos el módulo matemático

const a = 10;
const b = 5;

console.log(`Suma: ${math.suma(a, b)}`);
console.log(`Resta: ${math.resta(a, b)}`);
console.log(`Multiplicación: ${math.multiplicacion(a, b)}`);
console.log(`División: ${math.division(a, b)}`);
