//Ejercicio 5
//const imprimirEnMayusculas = (texto) => {
   // console.log(texto.toUpperCase());
//};

// Ejemplo de uso
//imprimirEnMayusculas("guillermo dzis"); // Imprime "HOLA MUNDO"
//ejercicio 9
// app.js

